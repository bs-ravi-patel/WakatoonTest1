//
//  wakatoonSDK.h
//  wakatoonSDK
//
//  Created by bs-mac-4 on 09/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for wakatoonSDK.
FOUNDATION_EXPORT double wakatoonSDKVersionNumber;

//! Project version string for wakatoonSDK.
FOUNDATION_EXPORT const unsigned char wakatoonSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <wakatoonSDK/PublicHeader.h>


